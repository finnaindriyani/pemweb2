<?php
    phpinfo():
?>