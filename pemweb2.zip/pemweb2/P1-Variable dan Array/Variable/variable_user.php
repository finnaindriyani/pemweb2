<?php

//mendeklarasikan variabel
$nama = 'aziz';
$umur = '20';
$berat = 57.0;

//menampilkan variabel
echo 'Nama : '.$nama.'<br>';
echo 'Umur : '.$umur.'<br>';
echo 'Berat : '.$berat.'<br>';

echo '<hr>';

//menampilkan variabel tanpa penghubung
echo "Nama : $nama<br>";
echo "Umur : $umur<br>";
echo "Berat : $berat<br>";
?>