<?php

    //variabel system
    echo '<h3>Variabel System<h3>';
    echo 'Dokumen Root : '.$_SERVER['DOCUMENT_ROOT'].'<br>';
    echo 'Nama File : '.$_SERVER['PHP_SELF'].'<br>';

    ?>